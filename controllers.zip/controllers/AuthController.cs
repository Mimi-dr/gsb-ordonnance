﻿using GSB_Ordonnance.Models;
using MySql.Data.MySqlClient;

namespace GSB_Ordonnance.Controllers
{
    public class AuthController
    {
        /// <summary>
        /// Vérifie le RPPS et le mot de passe via BCrypt.
        /// Retourne le médecin si OK, null sinon.
        /// On ne met JAMAIS le mot de passe dans le WHERE SQL.
        /// </summary>
        public Medecin Authentifier(string numeroRPPS, string motDePasseClair)
        {
            string sql = "SELECT numMedecin, nom, prenom, specialite, motDePasse " +
                         "FROM MEDECIN WHERE numeroRPPS = @rpps";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@rpps", numeroRPPS);

                using (MySqlDataReader r = cmd.ExecuteReader())
                {
                    if (!r.Read()) return null;

                    string hashStocke = r.GetString("motDePasse");

                    // Vérification BCrypt côté C#, jamais dans le SQL
                    if (!BCrypt.Net.BCrypt.Verify(motDePasseClair, hashStocke))
                        return null;

                    return new Medecin
                    {
                        Id = r.GetInt32("numMedecin"),
                        Nom = r.GetString("nom"),
                        Prenom = r.GetString("prenom"),
                        Specialite = r.GetString("specialite")
                    };
                }
            }
        }
    }
}