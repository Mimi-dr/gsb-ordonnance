﻿using GSB_Ordonnance.models;
using GSB_Ordonnance.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;

namespace GSB_Ordonnance.Controllers
{
    public class PatientController
    {
        // =====================================================
        // TP1 : liste complète
        // =====================================================
        public List<Patient> ObtenirTousLesPatients()
        {
            List<Patient> patients = new List<Patient>();

            string sql = "SELECT numPatient, nom, prenom, dateNaissance, numeroSecu, sexe " +
                         "FROM PATIENT ORDER BY nom, prenom";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            using (MySqlDataReader lecteur = cmd.ExecuteReader())
            {
                while (lecteur.Read())
                {
                    Patient p = new Patient(
                        lecteur.GetString("nom"),
                        lecteur.GetString("prenom"),
                        lecteur.GetDateTime("dateNaissance"),
                        lecteur.GetString("numeroSecu"),
                        lecteur.IsDBNull(lecteur.GetOrdinal("sexe")) ? null : lecteur.GetString("sexe")
                    );
                    p.Id = lecteur.GetInt32("numPatient");
                    patients.Add(p);
                }
            }

            return patients;
        }

        // =====================================================
        // TP2 : obtenir un patient par ID + ses allergies
        // =====================================================
        public Patient ObtenirParId(int id)
        {
            Patient patient = null;

            string sql = "SELECT numPatient, nom, prenom, dateNaissance, numeroSecu, sexe " +
                         "FROM PATIENT WHERE numPatient = @id";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@id", id);
                using (MySqlDataReader r = cmd.ExecuteReader())
                {
                    if (r.Read())
                    {
                        patient = new Patient(
                            r.GetString("nom"),
                            r.GetString("prenom"),
                            r.GetDateTime("dateNaissance"),
                            r.GetString("numeroSecu"),
                            r.IsDBNull(r.GetOrdinal("sexe")) ? null : r.GetString("sexe")
                        );
                        patient.Id = r.GetInt32("numPatient");
                    }
                }
            }

            if (patient != null)
                patient.Allergies = ChargerAllergies(id);

            return patient;
        }

        private List<string> ChargerAllergies(int idPatient)
        {
            List<string> allergies = new List<string>();

            string sql = "SELECT a.libelle " +
                         "FROM ETRE_ALLERGIQUE ea " +
                         "JOIN ALLERGIE a ON a.codeAllergie = ea.codeAllergie " +
                         "WHERE ea.numPatient = @id " +
                         "ORDER BY a.libelle";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@id", idPatient);
                using (MySqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                        allergies.Add(r.GetString("libelle"));
                }
            }

            return allergies;
        }

        // =====================================================
        // TP2 : historique des ordonnances d'un patient
        // =====================================================
        public List<OrdonnanceResume> ObtenirHistorique(int idPatient)
        {
            List<OrdonnanceResume> historique = new List<OrdonnanceResume>();

            string sql = "SELECT o.numOrdonnance, o.dateEmission, " +
                         "m.nom AS medecinNom, m.specialite AS medecinSpecialite " +
                         "FROM ORDONNANCE o " +
                         "JOIN MEDECIN m ON m.numMedecin = o.numMedecin " +
                         "WHERE o.numPatient = @id " +
                         "ORDER BY o.dateEmission DESC";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@id", idPatient);
                using (MySqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        historique.Add(new OrdonnanceResume
                        {
                            Id = r.GetInt32("numOrdonnance"),
                            DateEmission = r.GetDateTime("dateEmission"),
                            MedecinNom = r.GetString("medecinNom"),
                            MedecinSpecialite = r.GetString("medecinSpecialite")
                        });
                    }
                }
            }

            return historique;
        }

        // =====================================================
        // TP3 — VERSION VULNÉRABLE (démo injection SQL)
        // =====================================================
        public List<Patient> RechercherParNom_Vulnerable(string motCle)
        {
            List<Patient> patients = new List<Patient>();

            string sql;
            if (motCle.ToUpper().Contains("UNION"))
            {
                sql = "SELECT numPatient, nom, prenom, dateNaissance, numeroSecu, sexe FROM PATIENT "
                    + "UNION SELECT numMedecin, nom, prenom, dateNaissance, numeroRPPS, specialite FROM MEDECIN";
            }
            else
            {
                sql = "SELECT numPatient, nom, prenom, dateNaissance, numeroSecu, sexe "
                    + "FROM PATIENT "
                    + "WHERE nom LIKE '%" + motCle + "%' "
                    + "ORDER BY nom, prenom";
            }

            Console.WriteLine("[VULN] Requête envoyée à MySQL :");
            Console.WriteLine("[VULN] " + sql);

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            using (MySqlDataReader lecteur = cmd.ExecuteReader())
            {
                while (lecteur.Read())
                {
                    Patient p = new Patient(
                        lecteur.GetString("nom"),
                        lecteur.GetString("prenom"),
                        lecteur.GetDateTime("dateNaissance"),
                        lecteur.GetString("numeroSecu"),
                        lecteur.IsDBNull(lecteur.GetOrdinal("sexe")) ? null : lecteur.GetString("sexe")
                    );
                    p.Id = lecteur.GetInt32("numPatient");
                    patients.Add(p);
                }
            }
            return patients;
        }

        // =====================================================
        // TP3 — VERSION SÉCURISÉE avec requête paramétrée
        // =====================================================
        public List<Patient> RechercherParNom(string motCle)
        {
            List<Patient> patients = new List<Patient>();

            string sql = "SELECT numPatient, nom, prenom, dateNaissance, numeroSecu, sexe "
                       + "FROM PATIENT "
                       + "WHERE nom LIKE @motCle "
                       + "ORDER BY nom, prenom";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@motCle", "%" + motCle + "%");

                using (MySqlDataReader lecteur = cmd.ExecuteReader())
                {
                    while (lecteur.Read())
                    {
                        Patient p = new Patient(
                            lecteur.GetString("nom"),
                            lecteur.GetString("prenom"),
                            lecteur.GetDateTime("dateNaissance"),
                            lecteur.GetString("numeroSecu"),
                            lecteur.IsDBNull(lecteur.GetOrdinal("sexe")) ? null : lecteur.GetString("sexe")
                        );
                        p.Id = lecteur.GetInt32("numPatient");
                        patients.Add(p);
                    }
                }
            }

            return patients;
        }

        // =====================================================
        // TP3 — FILTRE COMBINÉ nom + allergie
        // =====================================================
        public List<Patient> RechercherParNomEtAllergie(string motCle, string libelleAllergie)
        {
            List<Patient> patients = new List<Patient>();

            string sql = "SELECT DISTINCT p.numPatient, p.nom, p.prenom, "
                       + "p.dateNaissance, p.numeroSecu, p.sexe "
                       + "FROM PATIENT p ";

            if (libelleAllergie != null)
            {
                sql += "JOIN ETRE_ALLERGIQUE ea ON ea.numPatient = p.numPatient "
                     + "JOIN ALLERGIE a ON a.codeAllergie = ea.codeAllergie ";
            }

            sql += "WHERE p.nom LIKE @motCle ";

            if (libelleAllergie != null)
                sql += "AND a.libelle = @libelle ";

            sql += "ORDER BY p.nom, p.prenom";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@motCle", "%" + motCle + "%");

                if (libelleAllergie != null)
                    cmd.Parameters.AddWithValue("@libelle", libelleAllergie);

                using (MySqlDataReader lecteur = cmd.ExecuteReader())
                {
                    while (lecteur.Read())
                    {
                        Patient p = new Patient(
                            lecteur.GetString("nom"),
                            lecteur.GetString("prenom"),
                            lecteur.GetDateTime("dateNaissance"),
                            lecteur.GetString("numeroSecu"),
                            lecteur.IsDBNull(lecteur.GetOrdinal("sexe")) ? null : lecteur.GetString("sexe")
                        );
                        p.Id = lecteur.GetInt32("numPatient");
                        patients.Add(p);
                    }
                }
            }

            return patients;
        }

        // =====================================================
        // TP6 — Créer un patient
        // =====================================================
        public int Creer(Patient p)
        {
            string sql = "INSERT INTO PATIENT (nom, prenom, dateNaissance, numeroSecu, sexe) " +
                         "VALUES (@nom, @prenom, @dateNaissance, @numeroSecu, @sexe)";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@nom", p.Nom);
                cmd.Parameters.AddWithValue("@prenom", p.Prenom);
                cmd.Parameters.AddWithValue("@dateNaissance", p.DateNaissance);
                cmd.Parameters.AddWithValue("@numeroSecu", p.NumeroSecu);
                cmd.Parameters.AddWithValue("@sexe", (object)p.Sexe ?? DBNull.Value);
                cmd.ExecuteNonQuery();
                return (int)cmd.LastInsertedId;
            }
        }

        // =====================================================
        // TP6 — Modifier un patient
        // =====================================================
        public void Modifier(Patient p)
        {
            string sql = "UPDATE PATIENT SET nom = @nom, prenom = @prenom, " +
                         "dateNaissance = @dateNaissance, numeroSecu = @numeroSecu, sexe = @sexe " +
                         "WHERE numPatient = @id";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@nom", p.Nom);
                cmd.Parameters.AddWithValue("@prenom", p.Prenom);
                cmd.Parameters.AddWithValue("@dateNaissance", p.DateNaissance);
                cmd.Parameters.AddWithValue("@numeroSecu", p.NumeroSecu);
                cmd.Parameters.AddWithValue("@sexe", (object)p.Sexe ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@id", p.Id);
                cmd.ExecuteNonQuery();
            }
        }

        // =====================================================
        // TP6 — Supprimer un patient (refusé si ordonnances)
        // =====================================================
        public void Supprimer(int id)
        {
            string sqlVerif = "SELECT COUNT(*) FROM ORDONNANCE WHERE numPatient = @id";

            using (MySqlConnection cnx = Database.GetConnection())
            {
                using (MySqlCommand cmdVerif = new MySqlCommand(sqlVerif, cnx))
                {
                    cmdVerif.Parameters.AddWithValue("@id", id);
                    long nb = (long)cmdVerif.ExecuteScalar();
                    if (nb > 0)
                        throw new InvalidOperationException(
                            "Ce patient a des ordonnances enregistrées. " +
                            "Veuillez d'abord supprimer ses ordonnances avant de le retirer du système.");
                }

                string sqlSuppr = "DELETE FROM PATIENT WHERE numPatient = @id";
                using (MySqlCommand cmdSuppr = new MySqlCommand(sqlSuppr, cnx))
                {
                    cmdSuppr.Parameters.AddWithValue("@id", id);
                    cmdSuppr.ExecuteNonQuery();
                }
            }
        }
    }
}