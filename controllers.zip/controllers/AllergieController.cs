using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace GSB_Ordonnance.Controllers
{
    public class AllergieController
    {
        /// <summary>
        /// Retourne la liste des libellés d'allergies, triée alphabétiquement.
        /// </summary>
        public List<string> ObtenirLibelles()
        {
            List<string> libelles = new List<string>();

            string sql = "SELECT libelle FROM ALLERGIE ORDER BY libelle";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            using (MySqlDataReader lecteur = cmd.ExecuteReader())
            {
                while (lecteur.Read())
                {
                    libelles.Add(lecteur.GetString("libelle"));
                }
            }

            return libelles;
        }
    }
}
