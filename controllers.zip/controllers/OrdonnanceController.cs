﻿using GSB_Ordonnance.Models;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace GSB_Ordonnance.Controllers
{
    public class OrdonnanceController
    {
        public List<Medecin> ObtenirMedecins()
        {
            List<Medecin> medecins = new List<Medecin>();
            string sql = "SELECT numMedecin, nom, prenom, specialite FROM MEDECIN ORDER BY nom";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            using (MySqlDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    medecins.Add(new Medecin
                    {
                        Id = r.GetInt32("numMedecin"),
                        Nom = r.GetString("nom"),
                        Prenom = r.GetString("prenom"),
                        Specialite = r.GetString("specialite")
                    });
                }
            }
            return medecins;
        }

        public List<Medicament> ObtenirMedicaments()
        {
            List<Medicament> medicaments = new List<Medicament>();
            string sql = "SELECT codeMedicament, nom, dosage FROM MEDICAMENT ORDER BY nom";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            using (MySqlDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    medicaments.Add(new Medicament
                    {
                        Code = r.GetInt32("codeMedicament"),
                        Nom = r.GetString("nom"),
                        Dosage = r.GetString("dosage")
                    });
                }
            }
            return medicaments;
        }

        public void EnregistrerOrdonnance(int idMedecin, int idPatient,
            List<LignePrescription> lignes)
        {
            using (MySqlConnection cnx = Database.GetConnection())
            {
                MySqlTransaction transaction = cnx.BeginTransaction();
                try
                {
                    string sqlOrd = "INSERT INTO ORDONNANCE (numMedecin, numPatient) " +
                                    "VALUES (@idMedecin, @idPatient)";
                    int idOrdonnance;

                    using (MySqlCommand cmd = new MySqlCommand(sqlOrd, cnx, transaction))
                    {
                        cmd.Parameters.AddWithValue("@idMedecin", idMedecin);
                        cmd.Parameters.AddWithValue("@idPatient", idPatient);
                        cmd.ExecuteNonQuery();
                        idOrdonnance = (int)cmd.LastInsertedId;
                    }

                    string sqlLigne = "INSERT INTO CONTENIR " +
                        "(numOrdonnance, codeMedicament, posologie, dureeJours) " +
                        "VALUES (@numOrd, @codeMed, @posologie, @duree)";

                    foreach (LignePrescription ligne in lignes)
                    {
                        using (MySqlCommand cmd = new MySqlCommand(sqlLigne, cnx, transaction))
                        {
                            cmd.Parameters.AddWithValue("@numOrd", idOrdonnance);
                            cmd.Parameters.AddWithValue("@codeMed", ligne.CodeMedicament);
                            cmd.Parameters.AddWithValue("@posologie", ligne.Posologie);
                            cmd.Parameters.AddWithValue("@duree", ligne.DureeJours);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        // 8.2 — Chargement léger : liste des ordonnances d'un patient, sans les lignes
        public List<OrdonnanceResume> ObtenirOrdonnancesParPatient(int numPatient)
        {
            List<OrdonnanceResume> liste = new List<OrdonnanceResume>();
            string sql = "SELECT o.numOrdonnance, o.dateEmission, " +
                         "m.nom AS nomMedecin, m.prenom AS prenomMedecin " +
                         "FROM ORDONNANCE o " +
                         "JOIN MEDECIN m ON o.numMedecin = m.numMedecin " +
                         "WHERE o.numPatient = @numPatient " +
                         "ORDER BY o.dateEmission DESC";

            using (MySqlConnection cnx = Database.GetConnection())
            using (MySqlCommand cmd = new MySqlCommand(sql, cnx))
            {
                cmd.Parameters.AddWithValue("@numPatient", numPatient);
                using (MySqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        liste.Add(new OrdonnanceResume
                        {
                            Id = r.GetInt32("numOrdonnance"),
                            DateEmission = r.GetDateTime("dateEmission"),
                            MedecinNom = $"Dr {r.GetString("prenomMedecin")} {r.GetString("nomMedecin")}"
                        });
                    }
                }
            }
            return liste;
        }

        // 8.3 — Modification : efface les lignes existantes et réinsère les nouvelles
        public void ModifierOrdonnance(int idOrdonnance, int idMedecin, int idPatient,
            List<LignePrescription> lignes)
        {
            using (MySqlConnection cnx = Database.GetConnection())
            {
                MySqlTransaction transaction = cnx.BeginTransaction();
                try
                {
                    string sqlOrd = "UPDATE ORDONNANCE SET numMedecin = @idMedecin, " +
                                    "numPatient = @idPatient " +
                                    "WHERE numOrdonnance = @idOrdonnance";

                    using (MySqlCommand cmd = new MySqlCommand(sqlOrd, cnx, transaction))
                    {
                        cmd.Parameters.AddWithValue("@idMedecin", idMedecin);
                        cmd.Parameters.AddWithValue("@idPatient", idPatient);
                        cmd.Parameters.AddWithValue("@idOrdonnance", idOrdonnance);
                        cmd.ExecuteNonQuery();
                    }

                    string sqlDelete = "DELETE FROM CONTENIR WHERE numOrdonnance = @idOrdonnance";
                    using (MySqlCommand cmd = new MySqlCommand(sqlDelete, cnx, transaction))
                    {
                        cmd.Parameters.AddWithValue("@idOrdonnance", idOrdonnance);
                        cmd.ExecuteNonQuery();
                    }

                    string sqlLigne = "INSERT INTO CONTENIR " +
                        "(numOrdonnance, codeMedicament, posologie, dureeJours) " +
                        "VALUES (@numOrd, @codeMed, @posologie, @duree)";

                    foreach (LignePrescription ligne in lignes)
                    {
                        using (MySqlCommand cmd = new MySqlCommand(sqlLigne, cnx, transaction))
                        {
                            cmd.Parameters.AddWithValue("@numOrd", idOrdonnance);
                            cmd.Parameters.AddWithValue("@codeMed", ligne.CodeMedicament);
                            cmd.Parameters.AddWithValue("@posologie", ligne.Posologie);
                            cmd.Parameters.AddWithValue("@duree", ligne.DureeJours);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        // ============================================================
        // MÉTHODE DE TEST — Point 9 du barème
        // Simule une erreur volontaire après l'INSERT dans ORDONNANCE
        // pour démontrer que le rollback annule l'ensemble de l'opération.
        // À supprimer après avoir capturé les screenshots.
        // ============================================================
        public void EnregistrerOrdonnance_TestRollback(int idMedecin, int idPatient,
            List<LignePrescription> lignes)
        {
            using (MySqlConnection cnx = Database.GetConnection())
            {
                MySqlTransaction transaction = cnx.BeginTransaction();
                try
                {
                    // Étape 1 : INSERT dans ORDONNANCE — s'exécute normalement
                    string sqlOrd = "INSERT INTO ORDONNANCE (numMedecin, numPatient) " +
                                    "VALUES (@idMedecin, @idPatient)";
                    int idOrdonnance;

                    using (MySqlCommand cmd = new MySqlCommand(sqlOrd, cnx, transaction))
                    {
                        cmd.Parameters.AddWithValue("@idMedecin", idMedecin);
                        cmd.Parameters.AddWithValue("@idPatient", idPatient);
                        cmd.ExecuteNonQuery();
                        idOrdonnance = (int)cmd.LastInsertedId;
                    }

                    // Étape 2 : erreur volontaire — codeMedicament 99999 n'existe pas → FK violation
                    string sqlLigneCassee = "INSERT INTO CONTENIR " +
                        "(numOrdonnance, codeMedicament, posologie, dureeJours) " +
                        "VALUES (@numOrd, 99999, 'test', 1)";

                    using (MySqlCommand cmd = new MySqlCommand(sqlLigneCassee, cnx, transaction))
                    {
                        cmd.Parameters.AddWithValue("@numOrd", idOrdonnance);
                        cmd.ExecuteNonQuery(); // plante ici : FK violation
                    }

                    transaction.Commit();
                }
                catch (MySqlException ex)
                {
                    transaction.Rollback();
                    throw new System.Exception(
                        $"ROLLBACK déclenché — erreur FK sur CONTENIR.\n" +
                        $"Détail MySQL : {ex.Message}\n\n" +
                        $"Vérifiez phpMyAdmin : ni l'ordonnance ni les lignes ne doivent apparaître.",
                        ex);
                }
            }
        }
    }
}