﻿using GSB_Ordonnance.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using System;
using System.Collections.Generic;

namespace GSB_Ordonnance.Services
{
    public class OrdonnancePdfService
    {
        public void Generer(
            int idOrdonnance,
            DateTime dateEmission,
            string nomMedecin,
            string specialiteMedecin,
            string nomPatient,
            string dateNaissancePatient,
            string numeroSecu,
            List<LignePrescription> lignes,
            string cheminFichier)
        {
            QuestPDF.Settings.License = LicenseType.Community;

            Document.Create(doc =>
            {
                doc.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(2, Unit.Centimetre);
                    page.DefaultTextStyle(x => x.FontSize(11).FontFamily("Arial"));

                    // EN-TÊTE MÉDECIN
                    page.Header().Column(col =>
                    {
                        col.Item().BorderBottom(1).PaddingBottom(8).Row(row =>
                        {
                            row.RelativeItem().Column(c =>
                            {
                                c.Item().Text(nomMedecin)
                                    .Bold().FontSize(16);
                                c.Item().Text(specialiteMedecin)
                                    .FontSize(11).FontColor(Colors.Grey.Medium);
                            });

                            row.ConstantItem(160).AlignRight().Column(c =>
                            {
                                c.Item().Text($"Ordonnance #{idOrdonnance}")
                                    .Bold().FontSize(12);
                                c.Item().Text($"Le {dateEmission:dd/MM/yyyy}")
                                    .FontSize(10).FontColor(Colors.Grey.Medium);
                            });
                        });
                    });

                    // CORPS
                    page.Content().PaddingTop(20).Column(col =>
                    {
                        // Bloc patient
                        col.Item().Background(Colors.Grey.Lighten3)
                            .Padding(10).Column(p =>
                            {
                                p.Item().Text("PATIENT").Bold().FontSize(10)
                                    .FontColor(Colors.Grey.Medium);
                                p.Item().Text(nomPatient).Bold().FontSize(13);
                                p.Item().Text($"Né(e) le : {dateNaissancePatient}")
                                    .FontSize(10);
                                p.Item().Text($"N° Sécu : {numeroSecu}")
                                    .FontSize(10);
                            });

                        col.Item().PaddingTop(20).Text("PRESCRIPTION")
                            .Bold().FontSize(12);

                        col.Item().PaddingTop(8).Table(table =>
                        {
                            table.ColumnsDefinition(cols =>
                            {
                                cols.RelativeColumn(3);
                                cols.RelativeColumn(3);
                                cols.RelativeColumn(1);
                            });

                            // En-têtes tableau
                            table.Header(header =>
                            {
                                header.Cell().Background(Colors.Blue.Darken2)
                                    .Padding(6).Text("Médicament")
                                    .FontColor(Colors.White).Bold();
                                header.Cell().Background(Colors.Blue.Darken2)
                                    .Padding(6).Text("Posologie")
                                    .FontColor(Colors.White).Bold();
                                header.Cell().Background(Colors.Blue.Darken2)
                                    .Padding(6).Text("Durée")
                                    .FontColor(Colors.White).Bold();
                            });

                            // Lignes de prescription
                            bool pair = false;
                            foreach (LignePrescription ligne in lignes)
                            {
                                string bg = pair ? Colors.Grey.Lighten4 : Colors.White;
                                pair = !pair;

                                table.Cell().Background(bg).Padding(6)
                                    .Text(ligne.NomMedicament);
                                table.Cell().Background(bg).Padding(6)
                                    .Text(ligne.Posologie);
                                table.Cell().Background(bg).Padding(6)
                                    .Text($"{ligne.DureeJours} j");
                            }
                        });
                    });

                    // PIED DE PAGE
                    page.Footer().AlignCenter().Text(text =>
                    {
                        text.Span("Document généré par GSB Ordonnance — ")
                            .FontSize(8).FontColor(Colors.Grey.Medium);
                        text.Span(DateTime.Now.ToString("dd/MM/yyyy HH:mm"))
                            .FontSize(8).FontColor(Colors.Grey.Medium);
                    });
                });
            })
            .GeneratePdf(cheminFichier);
        }
    }
}