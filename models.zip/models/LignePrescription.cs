﻿namespace GSB_Ordonnance.Models
{
    public class LignePrescription
    {
        public int CodeMedicament { get; set; }
        public string NomMedicament { get; set; }
        public string Posologie { get; set; }
        public int DureeJours { get; set; }
    }
}