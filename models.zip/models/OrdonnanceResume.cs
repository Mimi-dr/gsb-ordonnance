﻿using System;

namespace GSB_Ordonnance.Models
{
    public class OrdonnanceResume
    {
        public int Id { get; set; }
        public DateTime DateEmission { get; set; }
        public string MedecinNom { get; set; }
        public string MedecinSpecialite { get; set; }
    }
}
