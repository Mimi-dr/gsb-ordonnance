﻿namespace GSB_Ordonnance.Models
{
    public class Medecin
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Specialite { get; set; }
        public string NomAffiche => $"Dr {Prenom} {Nom} ({Specialite})";
    }
}