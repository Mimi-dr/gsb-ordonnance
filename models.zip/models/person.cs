﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSB_Ordonnance.models
{
    public class person
    {
        private string name;
        private string firstname;
        private string birthdate;

        public string getfirstname() { return firstname; }
        public string getname() { return name; }
        public string getbirthdate() { return birthdate; }

        public void setfirstname(string newfirstname) { this.firstname = newfirstname; }
        public void setname(string newname) { this.name = newname; }
        public void setbirthdate(string newbirthdate) { this.birthdate = newbirthdate; }

        public person() { }
        public person(string newname, string newfirstname, string newbirthdate)
        { 
            this.name = newname;
            this.firstname = newfirstname;
            this.birthdate = newbirthdate;
        }



    }
}
