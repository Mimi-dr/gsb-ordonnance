﻿using System;
using System.Collections.Generic;

namespace GSB_Ordonnance.Models
{
    public class Patient
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public DateTime DateNaissance { get; set; }
        public string NumeroSecu { get; set; }
        public string Sexe { get; set; }
        public string NomComplet => $"{Prenom} {Nom}";
        public List<string> Allergies { get; set; }

        public Patient(string nom, string prenom, DateTime dateNaissance, string numeroSecu, string sexe = null)
        {
            Nom = nom;
            Prenom = prenom;
            DateNaissance = dateNaissance;
            NumeroSecu = numeroSecu;
            Sexe = sexe;
            Allergies = new List<string>();
        }

        public Patient()
        {
            Allergies = new List<string>();
        }

        public int CalculerAge()
        {
            DateTime today = DateTime.Today;
            int age = today.Year - DateNaissance.Year;
            if (DateNaissance.Date > today.AddYears(-age)) age--;
            return age;
        }
    }
}