﻿namespace GSB_Ordonnance.Models
{
    public class Medicament
    {
        public int Code { get; set; }
        public string Nom { get; set; }
        public string Dosage { get; set; }
        public string NomAffiche => $"{Nom} ({Dosage})";
    }
}